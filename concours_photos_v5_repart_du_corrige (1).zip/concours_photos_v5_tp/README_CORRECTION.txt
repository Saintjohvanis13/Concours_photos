Version reprise depuis la version corrigée.

Corrections importantes :
- base utilisée : projet1_tp2 ;
- clé primaire Utilisateur : idUtilisateur ;
- aucun changement dans la structure SQL ;
- connexion LDAP gardée dans config/ldap.php ;
- formulaire de connexion en POST vers index.php avec route=connexion en champ caché ;
- après connexion correcte : index.php?route=espace ;
- liens gardés sous la forme index.php?route=... ;
- ajout de views/404.php pour éviter une page blanche si la route est mauvaise.

Fichiers importants :
- index.php : routeur principal ;
- controllers/auth_ctrl.php : contrôle la connexion ;
- models/auth.php : LDAP + création/récupération utilisateur ;
- config/ldap.php : configuration LDAP ;
- views/login.php : formulaire de connexion.
