Projet Concours Photos - version TP avec contrôleurs

Chemin des pages : index.php?route=nom_de_la_page
Exemples :
- index.php?route=accueil
- index.php?route=connexion
- index.php?route=espace
- index.php?route=depot_photo
- index.php?route=vote
- index.php?route=admin

LDAP :
- fichier config/ldap.php
- même principe que l'exemple fourni : recherche avec supannAliasLogin puis bind avec uid.
- installer/activer php-ldap sur le serveur.

Comptes de test local si LDAP non disponible :
- admin / admin
- etudiant / etudiant

La base de données n'a pas été modifiée.
